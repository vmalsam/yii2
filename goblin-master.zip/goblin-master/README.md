goblin
======

Plan 9 commands in Go


Similar Projects
----------------

* [gobox](https://github.com/surma/gobox) 
* [goblin](https://bitbucket.org/amertune/goblin) - An old goblin effort by amertune.
